import app from './app';
app.init();
